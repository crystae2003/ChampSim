#ifndef MODIFICATIONS_H
#define MODIFICATIONS_H

#include <algorithm>
#include <vector>
#include <map>
#include <iostream>
#include "cache.h"

extern map <int, vector<int>> remapped;        // one set mapping to multiple sets.

extern int memory_oper_count;

extern int set_Misses_LLC[LLC_SET];
extern int set_Hits_LLC[LLC_SET];    

extern vector<int> heat[4];    //0 : Very Cold, 1: Cold, 2: Hot, 3: Very Hot

extern int remap_after_count;

#endif